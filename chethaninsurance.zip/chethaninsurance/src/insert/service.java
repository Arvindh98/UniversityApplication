package insert;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;



public class service {

	@SuppressWarnings("null")
	public int add( int account_number,String insured_name, String insured_street, String insured_city, String insured_state,
			long insured_zip, String business_segment) throws SQLException,NullPointerException {
		// TODO Auto-generated method stub
		System.out.println("bean1");
		bean b=new bean();
		//System.out.println(insured_name);
		b.setInsured_name(insured_name);
		//System.out.println(b);
		b.setInsured_street(insured_street);
		b.setInsured_city(insured_city);
		b.setInsured_state(insured_state);
		b.setInsured_zip(insured_zip);
		b.setBusiness_segment(business_segment);
		//b.setAccount_number(account_number);
		System.out.println(insured_name);
	
		
		PreparedStatement pst=null;
		Connection con=null;
		String seq ="select acc_num_seq.currval from dual";
		try
			{
				Class.forName("oracle.jdbc.OracleDriver");
				con= DriverManager.getConnection("jdbc:oracle:thin:"+"@10.219.34.3:1521:orcl","trg626","training626");
				System.out.println("connected");
			}catch(Exception e)
			{
				System.out.println(e);	
			}

		System.out.println(seq);
		//String query1 =" insert into account_creation values(acc_num_seq.nextval,?,?,?,?,?,?)";
		System.out.println("Q1");
		pst=con.prepareStatement("insert into account_creation values(acc_num_seq.nextval,?,?,?,?,?,?)");
		//pst = con.prepareStatement(query1);
		//pst.setInt(1,seq);
		pst.setString(1,b.getInsured_name());
		pst.setString(2,b.getInsured_street() );
		pst.setString(3,b.getInsured_city() );
		pst.setString(4,insured_state );
		pst.setLong(5, insured_zip);
		pst.setString(6, business_segment);
		pst.executeQuery();
		return 0;
	

	
	}
}
