package com.cg.una.controller;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/admin_page")
public class AdminLogin extends HttpServlet{
	public void doGet(HttpServletRequest rq,HttpServletResponse res)throws ServletException, IOException {
		
		res.setContentType("text/html");
		Connection cn = null;
		PrintWriter out = res.getWriter();
		RequestDispatcher rd=null;
		String uname=rq.getParameter("uname");
		String Pwd=rq.getParameter("pwd");
		
		if (uname.equals("admin")  && Pwd.equals("pass")) {
			rd = rq.getRequestDispatcher("/Admistratorupdateform.jsp");
			
		}
		else 
			rd = rq.getRequestDispatcher("/reject.html");
		
		rd.forward(rq, res);
		
		
		
	}
	

}
