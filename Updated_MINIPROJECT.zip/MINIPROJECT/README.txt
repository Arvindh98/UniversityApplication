STUDENT APPLICATION TABLE 
----------------------------
CREATE TABLE stu_app(id number PRIMARY KEY,name varchar2(30),dob varchar2(10),highqn varchar2(30),marks int,email varchar2(50));
 
 
ADMIN TABLE
------------
 
CREATE TABLE admin(uname varchar2(30),pwd varchar2(30));

Application Result
------------------
CREATE TABLE results(id number,status varchar(2));

Sequence
---------
CREATE SEQUENCE id_seq start with 1000 increment by 1;

Change the SQL command in 23 line in UniversityDAO
as:
ResultSet rs = stmt.executeQuery("SELECT id_seq.NEXTVAL FROM stu_app");
