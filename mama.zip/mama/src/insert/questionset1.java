package insert;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
 
import javax.jws.WebService;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 
@WebServlet("/questionset1")
public class questionset1 extends HttpServlet
{
	public  void doGet(HttpServletRequest request,HttpServletResponse response)  
	{
		try
		{
		RequestDispatcher rd = null;
		PreparedStatement ps=null;		
		ResultSet rs = null;
		Class.forName("oracle.jdbc.OracleDriver");
		Connection c=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg626", "training626");
		//int a4=0;
		PrintWriter out=response.getWriter();
		String temp="";
		String a1=request.getParameter("vehicletype");
		String a2=request.getParameter("vehiclemy");
		String a3=request.getParameter("vehiclemodel");
		String a4=request.getParameter("dailycd");
		String a5=request.getParameter("servicecenter");
		String a6=request.getParameter("limit");
		String a7=request.getParameter("limit2");
		
		
		/*temp=request.getParameter("question4");
		a4=Integer.parseInt(temp);*/
		String seq ="Select uses.NEXTVAL from DUAL";
		String sql="SELECT uses.CURRVAL FROM DUAL";
		ps = c.prepareStatement(seq);
		rs=ps.executeQuery();
		ps = c.prepareStatement(sql);
		rs=ps.executeQuery();
		int qid=0;
		if(rs.next())
		{
			qid=rs.getInt(1);
 
		}
		System.out.println(qid);
		String q1="Vehicle Type";
		String q2="Vehicle Model Year";
		String q3="Vehicle Model";
		String q4="Daily Comutate Distance";
		String q5="Service Center";
		String q6="Collission Coverage Limit";
		String q7="Bodily Injury Limit";
		
		
		String sqlins ="Insert into questionsandanswers values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		ps = c.prepareStatement(sqlins);
		ps.setInt(1,qid);
		ps.setString(2,q1);			
		ps.setString(3,a1);	
		ps.setString(4,q2);			
		ps.setString(5,a2);	
		ps.setString(6,q3);			
		ps.setString(7,a3);	
		ps.setString(8,q4);			
		ps.setString(9,a4);
		ps.setString(10,q5);
		ps.setString(11,a5);
		ps.setString(12,q6);
		ps.setString(13,a6);
		ps.setString(14,null);
		ps.setString(15,null);
		ps.setString(16,null);
		ps.setString(17,null);
		ps.setString(18,null);
		ps.setString(19,null);
		
		
		ps.executeUpdate();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
 
	}
}