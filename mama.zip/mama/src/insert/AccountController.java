package insert;
import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 

 
 
//import com.ram.services.BookService;
 @WebServlet("/account")
public class AccountController extends HttpServlet
{
public  void doGet(HttpServletRequest request,HttpServletResponse response) 
   throws ServletException,IOException 
{
	RequestDispatcher rd = null;
	RequestDispatcher req = null;
	String insured_name="";
	String insured_street="";
	String insured_city="";
	String insured_state="";
	long insured_zip=0;
	String business_segment="";
	int account_number=0;
 
	insured_name=request.getParameter("insured_name");
	insured_street=request.getParameter("insured_street");
	insured_city=request.getParameter("insured_city");
	insured_state=request.getParameter("insured_state");
	String insured_zip1=request.getParameter("zip");
	insured_zip=Integer.parseInt(insured_zip1);
    bean b =new bean();
   /* b.setInsured_name(insured_name);*/
   
	business_segment=request.getParameter("business_segment");
	 try 
	    {
 
	        String page = request.getParameter("business_segment");
 
 
	        System.out.println(1);
	        if(request.getParameter("business_segment").equals("BusinessAuto"))
	        {
	        	System.out.println(2);
	        	System.out.println(insured_name);
	            request.setAttribute("s1", page);
	            req= getServletContext().getRequestDispatcher("/bs.jsp");
	            req.forward(request, response);
	        }
	        else if(request.getParameter("business_segment").equals("Apartment"))
	        {
	            request.setAttribute("s2", page);
	             req = getServletContext().getRequestDispatcher("/apartment.jsp");
	            req.forward(request, response);
	        }
	        else if(request.getParameter("business_segment").equals("Restaurant"))
	        {
	            request.setAttribute("s3", page);
	             req = getServletContext().getRequestDispatcher("/restaurant.jsp");
	            req.forward(request, response);
	        }
	        else if(request.getParameter("business_segment").equals("General_Merchant"))
	        {
	            request.setAttribute("s3", page);
	             req = getServletContext().getRequestDispatcher("/General_Merchant.jsp");
	            req.forward(request, response);
	        }
 
 
	    } 
	    finally 
	    {
	       System.out.println("");
 
	    }
 
	 service c = new service();
 
 
 
	   int updateCount;
	try {
		updateCount = c.add(account_number,insured_name, insured_street, insured_city,insured_state,insured_zip,business_segment);
	 
			System.out.println("inserted "+updateCount+" record   Success");
 
			if (updateCount==1)
			{
				System.out.println("inserted succesfully");
 
			} else 
			{
				System.out.println(" not inserted succesfully");
			}
			//rd.forward(request, response);
	}	
      catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
     }
}
 

}

 