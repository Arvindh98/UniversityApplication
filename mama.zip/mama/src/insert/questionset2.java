package insert;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


	@WebServlet("/questionset2")
	public class questionset2 extends HttpServlet
	{
		public  void doGet(HttpServletRequest request,HttpServletResponse response)  
		{
			try
			{
			RequestDispatcher rd = null;
			PreparedStatement ps=null;		
			ResultSet rs = null;
			Class.forName("oracle.jdbc.OracleDriver");
			Connection c=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg626", "training626");
			//int a4=0;
			PrintWriter out=response.getWriter();
			String temp="";
			String a1=request.getParameter("restaurantType");
			String a2=request.getParameter("area");
			String a3=request.getParameter("Sprinklers");
			String a4=request.getParameter("cylinders");
			String a5=request.getParameter("finearts");
			String a6=request.getParameter("Damage");
			String a7=request.getParameter("Breakdown");
			String a8=request.getParameter("Coverage");
			String a9=request.getParameter("Injury");
			
			
			
			/*temp=request.getParameter("question4");
			a4=Integer.parseInt(temp);*/
			String seq ="Select uses.NEXTVAL from DUAL";
			String sql="SELECT uses.CURRVAL FROM DUAL";
			ps = c.prepareStatement(seq);
			rs=ps.executeQuery();
			ps = c.prepareStatement(sql);
			rs=ps.executeQuery();
			int qid=0;
			if(rs.next())
			{
				qid=rs.getInt(1);
	 
			}
			System.out.println(qid);
			String q1="restaurant Type";
			String q2="restaurant SQ.ft";
			String q3="NO. of Sprinklers";
			String q4="NO. of cylinders in kitchen";
			String q5="Fine Arts";
			String q6="Property Damage";
			String q7="Equipment Breakdown";
			String q8="Liability Coverage";
			String q9="Bodily Injury";
			
			
			String sqlins ="Insert into questionsandanswers values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			ps = c.prepareStatement(sqlins);
			ps.setInt(1,qid);
			ps.setString(2,q1);			
			ps.setString(3,a1);	
			ps.setString(4,q2);			
			ps.setString(5,a2);	
			ps.setString(6,q3);			
			ps.setString(7,a3);	
			ps.setString(8,q4);			
			ps.setString(9,a4);
			ps.setString(10,q5);
			ps.setString(11,a5);
			ps.setString(12,q6);
			ps.setString(13,a6);
			ps.setString(14,q7);
			ps.setString(15,a7);
			ps.setString(16,q8);
			ps.setString(17,a8);
			ps.setString(18,q9);
			ps.setString(19,a9);
			
			
			
			
			
			ps.executeUpdate();
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
	 
		}
	}

