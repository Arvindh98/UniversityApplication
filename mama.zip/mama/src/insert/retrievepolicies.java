package insert;

import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class retrievepolicies
{
	
	PreparedStatement pst=null;
	Connection con=null;
	RequestDispatcher rd = null;
	public  void doGet(HttpServletRequest request,HttpServletResponse response)  
	{
		
	try
	{
	  Class.forName("oracle.jdbc.OracleDriver");
	  Connection c=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg626", "training626");
	   //int a4=0;
	   PrintWriter out=response.getWriter();
	   String q=" select ";
	}
	catch(Exception e) {
		System.out.println(e);
	}
	}
}
