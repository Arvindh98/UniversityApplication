package com.cg.insure.controller;

import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.insure.bean.QuestionSetBean;
import com.cg.insure.service.InsureService;

@WebServlet("/AutoController")
public class AutoController extends HttpServlet
{
	public  void doGet(HttpServletRequest request,HttpServletResponse response)  
	{
		InsureService service = new InsureService(); 
		QuestionSetBean bean= new QuestionSetBean();
		
		try
		{
		PrintWriter out=response.getWriter();
		RequestDispatcher rd = null;
		String a1=request.getParameter("vehicletype");
		String a2=request.getParameter("vehiclemy");
		String a3=request.getParameter("vehiclemodel");
		String a4=request.getParameter("dailycd");
		String a5=request.getParameter("servicecenter");
		String a6=request.getParameter("limit");
		String a7=request.getParameter("limit2");
		bean.setA1(a1);
		bean.setA2(a2);
		bean.setA3(a3);
		bean.setA4(a4);
		bean.setA5(a5);
		bean.setA6(a6);
		bean.setA7(a7);
		service.questionSet1(bean);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
 
	}
	

}
