package com.cg.insure.controller;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.insure.bean.IdBean;
import com.cg.insure.service.InsureService;

@WebServlet("/UserGenerate")
public class UserGenerate extends HttpServlet 
{	
	InsureService service=new InsureService();
	public  void doGet(HttpServletRequest request,HttpServletResponse response)
	{
		String user=request.getParameter("user");
		String temp=request.getParameter("roll");
		int rollid=Integer.parseInt(temp);
		System.out.println(user+rollid);
		service.generateUserId(user,rollid);		
	}

}
