package com.cg.insure.controller;

import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.insure.bean.IdBean;
import com.cg.insure.bean.UsernameBean;
import com.cg.insure.service.InsureService;

@WebServlet("/LoginContoller")
public class LoginContoller  extends HttpServlet 
{
	IdBean bean = new IdBean();
	RequestDispatcher rd = null;
	InsureService service=new InsureService();
	public  void doGet(HttpServletRequest request,HttpServletResponse response)
	{	 	
		try
		{
			PrintWriter out=response.getWriter();
			String user=request.getParameter("user");
			String pass=request.getParameter("pass");
			bean.setCreator(user);				
			int i=service.loginValidation(user,pass);
			if (i>1) 
			{
				if(i==10002)
				{
					int x=service.exuser(user);
					System.out.println("x"+x);
					if(x>=1)
					{
						bean.setAccid(x);
						request.getRequestDispatcher("/userhome2.html").forward(request, response);					
					}
					else
					{
						UsernameBean bean1=new UsernameBean();
						bean1.setUser(user);
						request.getRequestDispatcher("/clienthome.jsp").forward(request, response);
					}
				}
				if(i==10003)
					request.getRequestDispatcher("/agenthome.jsp").forward(request, response);
				if(i==10001)
						request.getRequestDispatcher("/adminhome.html").forward(request, response);
			}
			else 
			{
				
				request.getRequestDispatcher("/adminlogin.jsp").include(request, response);
				out.print("\n*Enter the correct Credential..");
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
