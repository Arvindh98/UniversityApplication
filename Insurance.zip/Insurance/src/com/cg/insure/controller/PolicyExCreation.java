package com.cg.insure.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.insure.bean.IdBean;

@WebServlet("/PolicyExCreation")

public class PolicyExCreation extends HttpServlet
{
	IdBean bean = new IdBean();
	public  void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException 
	{
		RequestDispatcher rd = null;
		String insured_no=request.getParameter("user");
		int id=Integer.parseInt(insured_no);   
		bean.setAccid(id);
		String business_segment="";
		business_segment=request.getParameter("business_segment");
		request.getRequestDispatcher("/questions.jsp").forward(request, response);

	}
}
