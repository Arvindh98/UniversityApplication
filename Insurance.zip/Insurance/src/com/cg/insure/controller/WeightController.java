package com.cg.insure.controller;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.insure.bean.AccountBean;
import com.cg.insure.bean.PremiumBean;
import com.cg.insure.service.InsureService;
@WebServlet("/WeightController")

public class WeightController extends HttpServlet
{
	PremiumBean pbean = new PremiumBean(); 
	InsureService service =new InsureService();
	AccountBean bean=new AccountBean();
	public  void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException 
	{
		RequestDispatcher rd = null; 
		String type11=request.getParameter("restaurant type");
		String type12=request.getParameter("vehicle type");
		String type13=request.getParameter("apartment sq.Ft");
		String type14=request.getParameter("business type");
		String type2=" ";
		String type3=" ";
		String type4=" ";
		String type5=" ";
		String type6=" ";
		String type7=" ";
		String type8=" ";
		String type9="0";
		String type10="0";
		System.out.println(type12);
		System.out.println(type13);
		System.out.println(type14);
		if(type11!=null)
		{
			 type2=request.getParameter("restaurant sq ft");
			 type3=request.getParameter("number of sprinklers");
			 type4=request.getParameter("number of cylinders in kitchen");
			 type5=request.getParameter("fine arts");
			 type6=request.getParameter("property damage");
			 type7=request.getParameter("equipment breakdown");
			 type8=request.getParameter("liability coverage");
			 type9=request.getParameter("bodily injury");
			 int p1=Integer.parseInt(type11);
			 int p2=Integer.parseInt(type2);
			 int p3=Integer.parseInt(type3);
			 int p4=Integer.parseInt(type4);
			 int p5=Integer.parseInt(type5);
			 int p6=Integer.parseInt(type6);
			 int p7=Integer.parseInt(type7);
			 int p8=Integer.parseInt(type8);
			 int p9=Integer.parseInt(type9);
			 pbean.setId(2);
			 pbean.setP1(p1);
			 pbean.setP2(p2);
			 pbean.setP3(p3);
			 pbean.setP4(p4);
			 pbean.setP5(p5);
			 pbean.setP6(p6);
			 pbean.setP7(p7);
			 pbean.setP8(p8);
			 pbean.setP9(p9);
			 service.claculatePre(pbean);

		}
		if(type12!=null)
		{
			 type2=request.getParameter("vehicle model year");
			 type3=request.getParameter("vehicle model");
			 type4=request.getParameter("daily commute distance");
			 type5=request.getParameter("service centre");
			 type6=request.getParameter("collision coverage limit");
			 type7=request.getParameter("bodily injury limit");
			 type8=request.getParameter("uninsured motorist");
			 type9=request.getParameter("unknown hit or theft coverage");
			 type10=request.getParameter("property and liability");
			 int p1=Integer.parseInt(type12);
			 int p2=Integer.parseInt(type2);
			 int p3=Integer.parseInt(type3);
			 int p4=Integer.parseInt(type4);
			 int p5=Integer.parseInt(type5);
			 int p6=Integer.parseInt(type6);
			 int p7=Integer.parseInt(type7);
			 int p8=Integer.parseInt(type8);
			 int p9=Integer.parseInt(type9);
			 int p10=Integer.parseInt(type10);
			 pbean.setId(1);
			 pbean.setP1(p1);
			 pbean.setP2(p2);
			 pbean.setP3(p3);
			 pbean.setP4(p4);
			 pbean.setP5(p5);
			 pbean.setP6(p6);
			 pbean.setP7(p7);
			 pbean.setP8(p8);
			 pbean.setP9(p9);
			 pbean.setP10(p10);
			 service.claculatePre(pbean);
		}
		if(type13!=null)
		{
			 type2=request.getParameter("number of sprinklers");
			 type3=request.getParameter("bulid year");
			 type4=request.getParameter("property damage");
			 type5=request.getParameter("bodily injury limit");
			 type6=request.getParameter("number of floors");
			 type7=request.getParameter("number of fire exits");
			 type8=request.getParameter("asset theft limit");
			 int p1=Integer.parseInt(type13);
			 int p2=Integer.parseInt(type2);
			 int p3=Integer.parseInt(type3);
			 int p4=Integer.parseInt(type4);
			 int p5=Integer.parseInt(type5);
			 int p6=Integer.parseInt(type6);
			 int p7=Integer.parseInt(type7);
			 int p8=Integer.parseInt(type8);
			 pbean.setId(3);
			 pbean.setP1(p1);
			 pbean.setP2(p2);
			 pbean.setP3(p3);
			 pbean.setP4(p4);
			 pbean.setP5(p5);
			 pbean.setP6(p6);
			 pbean.setP7(p7);
			 pbean.setP8(p8);
			 service.claculatePre(pbean);

		}
		if(type14!=null)
		{
			 type2=request.getParameter("asset value");
			 type3=request.getParameter("inflammable objects");
			 type4=request.getParameter("property size");
			 type5=request.getParameter("property damage");
			 type6=request.getParameter("bodily injury");
			 type7=request.getParameter("asset theft limit");
			 type8=request.getParameter("liability coverage");
			 int p1=Integer.parseInt(type14);
			 int p2=Integer.parseInt(type2);
			 int p3=Integer.parseInt(type3);
			 int p4=Integer.parseInt(type4);
			 int p5=Integer.parseInt(type5);
			 int p6=Integer.parseInt(type6);
			 int p7=Integer.parseInt(type7);
			 int p8=Integer.parseInt(type8);
			 int p9=Integer.parseInt(type9);
			 int p10=Integer.parseInt(type10);
			 pbean.setId(4);
			 pbean.setP1(p1);
			 pbean.setP2(p2);
			 pbean.setP3(p3);
			 pbean.setP4(p4);
			 pbean.setP5(p5);
			 pbean.setP6(p6);
			 pbean.setP7(p7);
			 pbean.setP8(p8);
			 pbean.setP9(p9);
			 pbean.setP10(p10);
			 service.claculatePre(pbean);
		}
		System.out.println(type11);
	
	}


} 