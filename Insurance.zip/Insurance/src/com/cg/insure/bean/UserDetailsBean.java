package com.cg.insure.bean;

public class UserDetailsBean 
{
	private String name;
	private String pass;
	private int roolId;
	public UserDetailsBean()
	{
		super();
	}
	public UserDetailsBean(String name,String pass,int roolId)
	{
		this.name=name;
		this.pass=pass;
		this.roolId=roolId;
	}
	public String getName() 
	{
		return name;
	}
	public void setName(String name) 
	{
		this.name = name;
	}
	public String getPass() 
	{
		return pass;
	}
	public void setPass(String pass) 
	{
		this.pass = pass;
	}
	public int getRoolId() {
		return roolId;
	}
	public void setRoolId(int roolId) 
	{
		this.roolId = roolId;
	}
	@Override
	public String toString() {
		return "UserDetailsBean [name=" + name + ", pass=" + pass + ", roolId=" + roolId + "]";
	}
}
