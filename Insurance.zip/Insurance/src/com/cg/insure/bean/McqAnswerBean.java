package com.cg.insure.bean;

public class McqAnswerBean 
{
	private static String a1;
	private static String a2;
	private static String a3;
	public static String getA1() {
		return a1;
	}
	public void setA1(String a1) {
		this.a1 = a1;
	}
	public static String getA2() {
		return a2;
	}
	public void setA2(String a2) {
		this.a2 = a2;
	}
	public static String getA3() {
		return a3;
	}
	public void setA3(String a3) {
		this.a3 = a3;
	}
	@Override
	public String toString() {
		return "McqAnswerBean [a1=" + a1 + ", a2=" + a2 + ", a3=" + a3 + "]";
	}
	
	
}
