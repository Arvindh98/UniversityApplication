package com.cg.insure.bean;

public class AccountBean
{
	private static String insured_name;
	private static String insured_street;
	private static String insured_city;
	private static String insured_state;
	private static long insured_zip;
	private static String business_segment;
	private static int account_number;
	private static String username;
	public static String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public static String getInsured_name() 
	{
		return insured_name;
	}
	public void setInsured_name(String insured_name) 
	{
		this.insured_name = insured_name;
	}
	public static String getInsured_street() 
	{
		return insured_street;
	}
	public void setInsured_street(String insured_street) 
	{
		this.insured_street = insured_street;
	}
	public static String getInsured_city() 
	{
		return insured_city;
	}
	public void setInsured_city(String insured_city)
	{
		this.insured_city = insured_city;
	}
	public static String getInsured_state()
	{
		return insured_state;
	}
	public  void setInsured_state(String insured_state) 
	{
		this.insured_state = insured_state;
	}
	public static long getInsured_zip() 
	{
		return insured_zip;
	}
	public void setInsured_zip(long insured_zip) 
	{
		this.insured_zip = insured_zip;
	}
	public static String getBusiness_segment() 
	{
		return business_segment;
	}
	public void setBusiness_segment(String business_segment) 
	{
		this.business_segment = business_segment;
	}
	public static int getAccount_number() {
		return account_number;
	}
	public void setAccount_number(int account_number) 
	{
		this.account_number = account_number;
	}
	public static String string()
	{
		return "AccountBean [insured_name=" + insured_name + ", insured_street=" + insured_street + ", insured_city="
				+ insured_city + ", insured_state=" + insured_state + ", insured_zip=" + insured_zip
				+ ", business_segment=" + business_segment + ", account_number=" + account_number +"   "+username+"]";
	}
	@Override
	public String toString() 
	{
		return "AccountBean [insured_name=" + insured_name + ", insured_street=" + insured_street + ", insured_city="
				+ insured_city + ", insured_state=" + insured_state + ", insured_zip=" + insured_zip
				+ ", business_segment=" + business_segment + ", account_number=" + account_number +"   "+username+"]";
	}
}
