package com.cg.insure.bean;

public class PremiumBean 
{
	private static int id=0;
	private static int p1=0;
	private static int p2=0;
	private static int p3=0;
	private static int p4=0;
	private static int p5=0;
	private static int p6=0;
	private static int p7=0;
	private static int p8=0;
	private static int p9=0;
	private static int p10=0;
	
	public static int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public static int getP1() {
		return p1;
	}
	public void setP1(int p1) {
		this.p1 = p1;
	}
	public static int getP2() {
		return p2;
	}
	public void setP2(int p2) {
		this.p2 = p2;
	}
	public static int getP3() {
		return p3;
	}
	public void setP3(int p3) {
		this.p3 = p3;
	}
	public static int getP4() {
		return p4;
	}
	public void setP4(int p4) {
		this.p4 = p4;
	}
	public static int getP5() {
		return p5;
	}
	public void setP5(int p5) {
		this.p5 = p5;
	}
	public static int getP6() {
		return p6;
	}
	public void setP6(int p6) {
		this.p6 = p6;
	}
	public static int getP7() {
		return p7;
	}
	public void setP7(int p7) {
		this.p7 = p7;
	}
	public static int getP8() {
		return p8;
	}
	public void setP8(int p8) {
		this.p8 = p8;
	}
	public static int getP9() {
		return p9;
	}
	public void setP9(int p9) {
		this.p9 = p9;
	}
	public static int getP10() {
		return p10;
	}
	public void setP10(int p10) {
		this.p10 = p10;
	}
	@Override
	public String toString() {
		return "PremiumBean [id=" + id + ", p1=" + p1 + ", p2=" + p2 + ", p3=" + p3 + ", p4=" + p4 + ", p5=" + p5
				+ ", p6=" + p6 + ", p7=" + p7 + ", p8=" + p8 + ", p9=" + p9 + ", p10=" + p10 + "]";
	}
	

}
