package com.cg.insure.dao;

import java.sql.*;

import com.cg.insure.bean.AccountBean;
import com.cg.insure.bean.LoginBean;
import com.cg.insure.bean.QuestionSetBean;
import com.cg.insure.bean.UserDetailsBean;
import com.cg.insure.util.CommonCon;

public class InsureDao
{
	Connection c=null;
	CommonCon connection=null;
	PreparedStatement ps=null;		
	ResultSet rs = null;
	UserDetailsBean beanu =new UserDetailsBean();
	public int userId()
	{
		int id=0;
		try
		{
			Class.forName("oracle.jdbc.OracleDriver");
			c=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg628", "training628");
			String seq ="Select user_seq.NEXTVAL from DUAL";
			String sql="SELECT user_seq.CURRVAL FROM DUAL";
			ps = c.prepareStatement(seq);
			rs=ps.executeQuery();
			ps = c.prepareStatement(sql);
			rs=ps.executeQuery();
			if(rs.next())
			{
				id=rs.getInt(1);
						
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return id;
	}
	public int seq()
	{
		int id=0;
		try
		{
			Class.forName("oracle.jdbc.OracleDriver");
			c=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg628", "training628");
			String seq ="Select seq.NEXTVAL from DUAL";
			String sql="SELECT seq.CURRVAL FROM DUAL";
			ps = c.prepareStatement(seq);
			rs=ps.executeQuery();
			ps = c.prepareStatement(sql);
			rs=ps.executeQuery();
			if(rs.next())
			{
				id=rs.getInt(1);
						
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		return id;
	}
	public void userDetails(UserDetailsBean bean)
	{
		try
		{
			Class.forName("oracle.jdbc.OracleDriver");
			c=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg628", "training628");
			String seq ="Insert into userr values(?,?,?)";
			ps = c.prepareStatement(seq);
			ps.setString(1,bean.getName());			
			ps.setString(2,bean.getPass());	
			ps.setInt(3,bean.getRoolId());	
			ps.executeUpdate();	
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	public String LoginValidation(LoginBean bean)
	{
		String pass="";

		try
		{
			
			String user=bean.getUser();
			Class.forName("oracle.jdbc.OracleDriver");
			c=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg628", "training628");
			String sql="Select PASSWORD from userr where USERNAME=?";
			ps = c.prepareStatement(sql);
			ps.setString(1,user);	
			rs=ps.executeQuery();
			if(rs.next())
			{
				pass=rs.getString(1);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}		
		return pass;
	}
	public void accountDetails(AccountBean bean)
	{
		try
		{
			Class.forName("oracle.jdbc.OracleDriver");
			c=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg628", "training628");
			String sql="Insert into account values(?,?,?,?,?,?,?)";
			int insured_zip=(int) bean.getInsured_zip();
			ps = c.prepareStatement(sql);
			ps.setInt(1,bean.getAccount_number());			
			ps.setString(2,bean.getInsured_name());	
			ps.setString(3,bean.getInsured_street());
			ps.setString(4,bean.getInsured_city());
			ps.setString(5,bean.getInsured_state());
			ps.setInt(6,insured_zip);
			ps.setString(7,bean.getBusiness_segment());
			ps.executeUpdate();	
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	public void premium(int amount)
	{
		try
		{
			int id=0;
			Class.forName("oracle.jdbc.OracleDriver");
			c=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg603", "training603");
			String sql="Insert into premiums values(?,?)";
			ps = c.prepareStatement(sql);
			ps.setInt(1,id);
			ps.setInt(2,amount);
			ps.executeUpdate();		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

}
