package com.cg.insure.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Scanner;

import com.cg.insure.bean.AccountBean;
import com.cg.insure.bean.LoginBean;
import com.cg.insure.bean.PremiumBean;
import com.cg.insure.bean.QuestionSetBean;
import com.cg.insure.bean.UserDetailsBean;
import com.cg.insure.controller.AccountController;
import com.cg.insure.dao.InsureDao;

public class InsureService 
{
	
	InsureDao dao=new InsureDao();
	public void generateUserId(String user,int rollid)
	{
		UserDetailsBean bean = new UserDetailsBean();
		SimpleDateFormat geek = new SimpleDateFormat("dd"); 
	    Calendar c1 = Calendar.getInstance(); 
	    String d = geek.format(c1.getTime());
	    int id=dao.userId();
	    user+=d+id;
	    bean.setName(user);
	    bean.setPass(user);
	    bean.setRoolId(rollid);
	    dao.userDetails(bean);
	}
	public int loginValidation(String user,String pass)
	{
		int i=1;
		LoginBean bean= new LoginBean();
		bean.setUser(user);
		bean.setPass(pass);
		String password=dao.LoginValidation(bean);
		if(pass.equals(password))
		{
			i=2;
		}
		else
		{
			i=1;
		}
		return i;
	}
	public void AccountDetails(AccountBean bean)
	{
		int id=dao.seq();
		bean.setAccount_number(id);
		System.out.println(bean);
		dao.accountDetails(bean);
	}
	public void claculatePre(PremiumBean bean)
	{
		System.out.println(bean);
		int sum = bean.getP1()+bean.getP2()+bean.getP2()+bean.getP3()+bean.getP4()+bean.getP5()+bean.getP6()+bean.getP7()+bean.getP8()+bean.getP9()+bean.getP10();
		sum*=50;
		dao.premium(sum);
		System.out.println(sum);
	}
}
