package com.cg.insure.controller;

import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.insure.service.InsureService;

@WebServlet("/LoginContoller")
public class LoginContoller  extends HttpServlet 
{
	RequestDispatcher rd = null;
	InsureService service=new InsureService();
	public  void doGet(HttpServletRequest request,HttpServletResponse response)
	{	 	
		try
		{
			PrintWriter out=response.getWriter();
			String user=request.getParameter("user");
			String pass=request.getParameter("pass");
			int i=service.loginValidation(user,pass);
			if (i==2) 
			{
				request.getRequestDispatcher("/adminhome.jsp").forward(request, response);
			}
			else 
			{
				
				request.getRequestDispatcher("/adminlogin.jsp").include(request, response);
				out.print("\n*Enter the correct Credential..");
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
