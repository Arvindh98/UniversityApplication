package com.cg.insure.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.insure.bean.AccountBean;
import com.cg.insure.service.InsureService;

@WebServlet("/AccountController")
public class AccountController extends HttpServlet
{
	InsureService service =new InsureService();
	AccountBean bean=new AccountBean();
	public  void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException 
	{
	RequestDispatcher rd = null;
	String insured_name="";
	String insured_street="";
	String insured_city="";
	String insured_state="";
	long insured_zip=0;
	String business_segment="";
 
	insured_name=request.getParameter("name");
	insured_street=request.getParameter("street");
	insured_city=request.getParameter("city");
	insured_state=request.getParameter("state");
	String insured_zip1=request.getParameter("zipcode");
	insured_zip=Integer.parseInt(insured_zip1);   
	business_segment=request.getParameter("business_segment");
	bean.setInsured_name(insured_name);
	bean.setInsured_street(insured_street);
	bean.setInsured_city(insured_city);
	bean.setInsured_state(insured_state);
	bean.setInsured_zip(insured_zip);
	bean.setBusiness_segment(business_segment);
	request.getRequestDispatcher("/questions.jsp").forward(request, response);
	}
}
	